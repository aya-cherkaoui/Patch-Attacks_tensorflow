"""
GAN Estimator API.
"""
from art.estimators.gan.tensorflow import TensorFlowV2GAN
